/********************************************************************************
	Title: 	  otherClass.cpp
	Authors:  Anthony Filigenzi, Jocelyn Lee, Kylie Truong & Adam Yang
	Date:  	  09/11/2024
	Purpose:   
*********************************************************************************/

#include "otherClass.h"

using namespace std;

class Info{
private:
	string favPokemon[maxPokemon];
    string favStarter[maxPokemon];
public:
	friend class Student;
	friend class PokedexInfo;

	//Function
//****************************************************************************
//                                 displayPokedex()
//
// task:          Shows User the pokemon from file
//
////****************************************************************************

	void displayPokedex(){
	fstream pokeDisplay;
	pokeDisplay.open("pokedex.txt");
	int length;

    if (filesystem::file_size("pokedex.txt") == 0){
        cout << "NO ENTRIES FOUND" << endl;
        cout << endl;
        pokeDisplay.close();
    }
    else {
        cout << endl;
        cout << pokeDisplay.rdbuf();
        cout << endl;
    }

    }
	};
