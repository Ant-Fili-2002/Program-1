/*************************************************************************
	Title: 	 dataClass.h
	Authors: Anthony Filigenzi, Jocelyn Lee, Kylie Truong & Adam Yang
	Date:  	 09/11/2024
	Purpose: Stores the information of students, their favorite 
 	         Pokemon and favorite starter Pokemon.
*************************************************************************/

#ifndef data_class_h
#define data_class_H


#include "pokedexDriver.h"


//Function prototypes of data Class
void addToPokedex();
void deletePokemon(int, int);


#endif 