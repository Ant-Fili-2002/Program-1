/*************************************************************************
	Title: 	 dataClass.cpp
	Authors: Anthony Filigenzi, Jocelyn Lee, Kylie Truong & Adam Yang
	Date:  	 09/11/2024
	Purpose: Puts student info into Pokedex
*************************************************************************/


#include "dataClass.h"
#include "otherClass.cpp"


class Student{
    Info pokeInfo;
private:
    string studentName[maxPokemon];
public:
    friend class PokedexInfo;
    //Get user input to learn about pokemon
    void addToPokedex(){
        cout << "A Wild Tech Student Appeared!";
        cout << "\nQUICK! Add Them to Your Pokedex!" << endl;
        cout << "Name of Student: ";
        cin.ignore();
        getline(cin, studentName[numIDs]);
        cout << "Name of Favorite Pokemon: ";
        getline(cin, pokeInfo.favPokemon[numIDs]);
        cout << "Name of Favorite Starter: ";
        getline(cin, pokeInfo.favStarter[numIDs]);
        cout << endl;

    //Record it to file
    fstream pokedexAdd;
    pokedexAdd.open("pokedex.txt", ios::app);
    pokedexAdd << "ID Number: " << numIDs << endl;
    pokedexAdd << "Student Name: " << studentName[numIDs] << endl;
    pokedexAdd << "Favorite Pokemon: " << pokeInfo.favPokemon[numIDs] << endl;
    pokedexAdd << "Favorite Starter: " << pokeInfo.favStarter[numIDs] << endl;
    numIDs++;
    pokedexAdd.close();
};
    //Remove from pokedex
    void deletePokemon(int numPokemon, int choicePokemon){
   fstream pokeDelete;
pokeDelete.open("pokedex.txt", std::ios::out);

//If it's the highest number
    if (numPokemon == choicePokemon){
        string lineRandom;
        //Loop until you find the right line
        for (int j = 0; j < (numPokemon*4)-4; j++){
            getline(pokeDelete, lineRandom);
        }
        pokeDelete << "";
        pokeDelete << "";
        pokeDelete << "";
        studentName[numPokemon] = "";
        pokeInfo.favPokemon[numPokemon] = "";
        pokeInfo.favStarter[numPokemon] = "";

    }
    else if (numPokemon > choicePokemon){
    for (int i = choicePokemon; i < numPokemon; ++i){
    studentName[i] = studentName[i + 1];
    pokeInfo.favPokemon[i] = pokeInfo.favPokemon[i + 1];
    pokeInfo.favStarter[i] = pokeInfo.favStarter[i + 1];
    }
    }
    numIDs--;

    for (int q = 1; q < numPokemon - 1; q++){
    pokeDelete << "ID Number: " << q << endl;
    pokeDelete << "Student Name: " << studentName[q] << endl;
    pokeDelete << "Favorite Pokemon: " << pokeInfo.favPokemon[q] << endl;
    pokeDelete << "Favorite Starter: " << pokeInfo.favStarter[q] << endl;
    }
    pokeDelete.close();

};
};
