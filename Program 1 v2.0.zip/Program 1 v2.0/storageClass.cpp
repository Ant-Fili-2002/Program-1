/********************************************************************************
	Title: 	  storageClass.cpp
	Authors:  Anthony Filigenzi, Jocelyn Lee, Kylie Truong & Adam Yang
	Date:  	  09/11/2024
	Purpose:  Pointer to an array of pointers to the data in the data class. 
*********************************************************************************/
#include "pokedexDriver.h"
#include "dataClass.cpp"
#include "storageClass.h"

using namespace std;
//Maximum number of entires is just like the first gen
const int maxPokemon = 150;
Student studentPoke;
Info infoPoke;


class PokedexInfo{

public:
//Functions
void pokedexCount(){
    fstream pokeCount;
    pokeCount.open("pokedex.txt");
    string line;
    int lineTotal = 0;
    int lineRead = 0;
    string s;
    int studentInfo = 0;


    fstream pokeCount;
    pokeCount.open("pokedex.txt");
    while(!pokeCount.eof()){
    getline(pokeCount, line);
    getline(pokeCount, studentPoke.studentName[studentInfo]);
    getline(pokeCount, infoPoke.favPokemon[studentInfo]);
    getline(pokeCount, infoPoke.favStarter[studentInfo]);
    lineTotal ++;
    studentInfo ++;
    }

    numIDs = lineTotal;



    pokeCount.close();
    
};
};