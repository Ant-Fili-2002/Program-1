/********************************************************************************
	Title: 	  otherClass.h
	Authors:  Anthony Filigenzi, Jocelyn Lee, Kylie Truong & Adam Yang
	Date:  	  09/11/2024
	Purpose:   
*********************************************************************************/

#include "pokedexDriver.h"

using namespace std;

//function prototype
void displayPokedex();