/********************************************************************************
	Title: 	    storagClass.h
	Authors:    Anthony Filigenzi, Jocelyn Lee, Kylie Truong & Adam Yang
	Date:  	    09/11/2024
	Purpose:    Header file for storageClass.cpp, includes function prototypes
*********************************************************************************/

#include "pokedexDriver.h"
#include "dataClass.cpp"
#include "otherClass.cpp"
using namespace std;

//Function Prototype

void pokedexCount(){
};