# Program 1
### Description: 
This code is designed to store information on pokedex-like tool we shall call "TTUdex". It will store info on students and their favorite pokemon

### Outline: 
The program will utilize saving files on the computer which stores information from the user

### Classes: 
Student info (name of student, name of favorite pokemon, and student's favorite starter)
